const container = document.querySelector(".container")
const column = document.getElementsByClassName("column")
const col1 = document.getElementById("1")
const col2 = document.getElementById("2")
const col3 = document.getElementById("3")
const col4 = document.getElementById("4")
const url = "../images/"
const imagetype = ".jpg"
let colNum = 1

// function getRandNum(){
//     return Math.floor(Math.random() * 17 + 1)
// }

// function loadImages (numOfImages = 10){
//     let colNum = 1
//     for (let i = 0; i < 10; i++){
//         let colRef = "col1"
//         const img=document.createElement ("img")
//         img.src = url + getRandNum() + imagetype
//         colRef.appendChild(img)
//         colNum++
//     }
// }

function getRandNum(){
    return Math.floor(Math.random() * 17 + 1)
}

let imageNum = getRandNum()

function loadImages (numOfImages = 30){
    
   

    for (let i = 0; i < numOfImages; i++){
        const img = document.createElement ("img")
        img.src = url + imageNum + imagetype
        imgWidth = img.width
        imgHeight = img.height

        console.log(imgWidth,imgHeight)


        if(imageNum % 4 === 0 && imgHeight > imgWidth){
            const multiDiv = document.createElement ("div")
            multiDiv.classList.add("multidiv")
            
            if(colNum == 1 ){
                multiDiv.appendChild(img)
                colNum++
            }else if (colNum == 2){
                col2.appendChild(multiDiv)
                colNum++
            }else if (colNum == 3){
                col3.appendChild(multiDiv)
                colNum++
            }else{
                col4.appendChild(multiDiv)
                colNum = 1
            }

        }
        
        
        if(colNum == 1 ){
            col1.appendChild(img)
            colNum++
        }else if (colNum == 2){
            col2.appendChild(img)
            colNum++
        }else if (colNum == 3){
            col3.appendChild(img)
            colNum++
        }else{
            col4.appendChild(img)
            colNum = 1
        }
         
        if (imageNum < 17){
            imageNum++
        }else{
            imageNum = 1
        }

    }
}

function fillMultiDiv(){
    let multiDivs = document.getElementsByClassName("multidiv")
    for ( let i = 0; i > multiDivs.length; i++){
        multiDivs[i].appendChild("img")
    }
}

loadImages()
fillMultiDiv()

